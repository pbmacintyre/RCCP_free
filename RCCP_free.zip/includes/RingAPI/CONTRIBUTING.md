- 5.4
    - https://github.com/zendframework/zend-diactoros
    - https://packagist.org/packages/guzzlehttp/psr7

https://packagist.org/providers/psr/http-message-implementation

**TODO** Add `ext-mcrypt` to `composer.json`