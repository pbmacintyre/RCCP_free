<?php
/**
 * Copyright (C) 2019 Paladin Business Solutions
 *
 */
return array(
    'username'     => '+13128589779', // your RingCentral account phone number
    'extension'    =>  '101', // or number
    'password'     => 'Char1tyMM',
    'clientId'     => 'LnLwce89TjSwLmAK6zU-MA',
    'clientSecret' => 'yourClientSecret',
    'server'       => 'https://platform.devtest.ringcentral.com', // for production - https://platform.ringcentral.com
    'smsNumber'    => '13128589779', // any of SMS-enabled numbers on your RingCentral account
    'mobileNumber' => '19029405827', // your own mobile number to which script will send sms
    'dateFrom'	   => '2018-03-12',  // dateFrom
    'dateTo'       => '2018-12-31'   // dateTo
);